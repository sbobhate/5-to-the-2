/** Automatically generated file. DO NOT MODIFY */
package com.firatdulger.game.go;

public final class BuildConfig {
    public final static boolean DEBUG = true;
}