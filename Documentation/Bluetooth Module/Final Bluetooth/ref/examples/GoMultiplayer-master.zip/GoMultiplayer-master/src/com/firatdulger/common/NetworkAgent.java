package com.firatdulger.common;

import java.util.concurrent.Callable;

import android.os.AsyncTask;
import android.util.Log;

//Executes task specified in Task parameter on background thread 
	//and processes with the given EventListener
	public class NetworkAgent extends AsyncTask<Callable<?>, Void, Object> {
		
		private EventListenerImpl listener;

		public NetworkAgent(EventListenerImpl listener) {
			this.listener = listener;
		}

		@Override
		protected Object doInBackground(Callable<?>... params) {
			try {
				return params[0].call();
			} catch (Exception e) {
				Log.e("NetworkAgent","Exception during backgound task",e);
			}
			return null;
		}

		@Override
		protected void onPostExecute(Object result) {
			listener.onEvent(result);
		}

	}