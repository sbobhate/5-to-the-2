package com.firatdulger.game.go;

import java.util.ArrayList;
import java.util.concurrent.Callable;

import org.jivesoftware.smack.packet.Message;
import org.jivesoftware.smack.packet.Presence;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.DialogInterface;
import android.content.Intent;
import android.graphics.Typeface;
import android.os.Bundle;
import android.os.Handler;
import android.os.SystemClock;
import android.util.Log;
import android.view.Menu;
import android.view.View;
import android.widget.Button;
import android.widget.Chronometer;
import android.widget.ImageView;
import android.widget.RelativeLayout;
import android.widget.TextView;

import com.firatdulger.common.EventListenerImpl;
import com.firatdulger.common.NetworkAgent;
import com.firatdulger.game.go.RoomActivity.PeopleFragment;
import com.firatdulger.game.go.RoomActivity.RoomHomeFragment;
import com.firatdulger.xmpp.AccountManager;
import com.firatdulger.xmpp.XMPPManager;

public class BoardActivity extends Activity {
	
	private String TAG = "BoardActivity";

	private static BoardActivity mBoardActivity;
	private Handler mHandler;
	private String opponent = "";
	private boolean myTurn = true;
	private boolean myColor = true; //true black false white
	private boolean passed = false;
	private boolean gameOver = false;

	private long player1ElapsedTime = 0;
	private long player2ElapsedTime = 0;
	private Chronometer player1Chrono;
	private Chronometer player2Chrono;
	
	private static Stone[][] board = new Stone[9][9];

	public static BoardActivity getInstance() {
		return mBoardActivity;
	}

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_board);
		loadStones();
		mBoardActivity=this;
		mHandler = new Handler();
		opponent = getIntent().getExtras().getString("opponent");
		myColor = getIntent().getExtras().getString("myColor").equals("black");
		myTurn = myColor;
		setTitle("Playing with "+opponent);
		if(myColor) {//black
			((TextView)findViewById(R.id.textPlayer2)).setText(AccountManager.getInstance(this).getUsername().replace(getString(R.string.jabber_id_appendix), ""));
			((TextView)findViewById(R.id.textPlayer2)).setTypeface(null, Typeface.BOLD);
			((TextView)findViewById(R.id.textPlayer1)).setText(opponent);
			((Button)findViewById(R.id.buttonPass)).setEnabled(true);
		} else { //white
			((TextView)findViewById(R.id.textPlayer1)).setText(AccountManager.getInstance(this).getUsername().replace(getString(R.string.jabber_id_appendix), ""));
			((TextView)findViewById(R.id.textPlayer1)).setTypeface(null, Typeface.BOLD);
			((TextView)findViewById(R.id.textPlayer2)).setText(opponent);
			((Button)findViewById(R.id.buttonPass)).setEnabled(false);
		}
		
		for(int i=0;i<9;i++)
			for(int j=0;j<9;j++)
				board[i][j]=null;

		player1Chrono = (Chronometer)findViewById(R.id.player1Chrono);
		player2Chrono = (Chronometer)findViewById(R.id.player2Chrono);
		
		player2Chrono.setBase(SystemClock.elapsedRealtime() + player2ElapsedTime);
		player2Chrono.start();
	}
	
	@Override
	public boolean onCreateOptionsMenu(Menu menu) {
		// Inflate the menu; this adds items to the action bar if it is present.
		getMenuInflater().inflate(R.menu.board, menu);
		return true;
	}
	
	@Override
	public void onResume() {
		super.onResume();
		XMPPManager.getInstance(this).addMessageListener(messageListener);
		XMPPManager.getInstance(this).addPresenceListener(presenceListener);
	}
	
	@Override
	public void onStop() {
		super.onStop();
		XMPPManager.getInstance(this).removeMessageListener(messageListener);
		XMPPManager.getInstance(this).removePresenceListener(presenceListener);
	}
	
	private EventListenerImpl messageListener = new EventListenerImpl() {
		@Override
		public void onEvent(Object arg0) {
			Message message = (Message) arg0;
			String[] messageSplitted = message.getBody().split(";;");
			if(messageSplitted==null || messageSplitted.length<2) return;
			String header = messageSplitted[0];
			if(!message.getFrom().contains(opponent)) return;
			if (header.equals("move")) {
				String info = messageSplitted[1];
				if(info.contains(",")) {
					move(Integer.parseInt(info.split(",")[0]),Integer.parseInt(info.split(",")[1]));
				} else if (info.equals("undo")) {
					//TODO
				} else if (info.equals("pass")) {
					pass();
				} else if (info.equals("pass_2")) {
					gameOver();
				} else if (info.equals("resign")) {
					opponentResigned();
				}
			} else if (header.equals("gamecht")) {
				//TODO
			} else if (header.equals("visitor")) {
				//TODO
			}
		}
	};
	
	private EventListenerImpl presenceListener = new EventListenerImpl() {
		@Override
		public void onEvent(Object arg0) {
			if(((Presence)arg0).getFrom().contains(opponent) && !((Presence)arg0).isAvailable()) {
				opponentIsOffline();
			}
		}
	};
	
	public void stoneClicked(final View view) {
		if(!myTurn || gameOver) return;
		String TAG = (String) view.getTag();
//		Log.i(TAG, "stoneClicked: "+TAG);
		String[] TAGSplitted = TAG.split(":");
		String coordinate_x = TAGSplitted[0];
		String coordinate_y = TAGSplitted[1];
		int x = Integer.parseInt(coordinate_x);
		int y = Integer.parseInt(coordinate_y);
		if(board[y][x]!=null || !putStone(1, y, x)) {Log.d(TAG,"can not play: "+y+" "+x);return;}
		XMPPManager.getInstance(this).sendMessage(opponent+getString(R.string.jabber_id_appendix)+"@"+getString(R.string.xmpp_server_address), coordinate_x+","+coordinate_y, "move");
		((ImageView)view).setImageResource(myColor?R.drawable.stone_black:R.drawable.stone_white);
		((TextView)findViewById(R.id.whoPlays)).setText(myColor?"White plays":"Black plays");
		switchPlayer(false);
//		printBoard();
	}
	
	public void passClicked(final View view) {
		if(!myTurn) return;
		if(passed) { //game over! 
			XMPPManager.getInstance(this).sendMessage(opponent+getString(R.string.jabber_id_appendix)+"@"+getString(R.string.xmpp_server_address), "pass_2", "move");
			gameOver();
			return;
		}
		XMPPManager.getInstance(this).sendMessage(opponent+getString(R.string.jabber_id_appendix)+"@"+getString(R.string.xmpp_server_address), "pass", "move");
		((TextView)findViewById(R.id.whoPlays)).setText(myColor?"White plays":"Black plays");
		switchPlayer(false);
	}
	
	public void ResignClicked(final View view) {
		XMPPManager.getInstance(this).sendMessage(opponent+getString(R.string.jabber_id_appendix)+"@"+getString(R.string.xmpp_server_address), "resign", "game");
		gameOver();
		return;
	}
	
	public void move(final int x,final int y) {
		if(myTurn) return;
		putStone(2, y, x);
		mHandler.post(new Runnable() {
			@Override
			public void run() {
				((ImageView)findViewById(stones[x][y])).setImageResource(myColor?R.drawable.stone_white:R.drawable.stone_black);
				((TextView)findViewById(R.id.whoPlays)).setText(myColor?"Black plays":"White plays");
				switchPlayer(true);
			}
		});
		passed = false;
//		printBoard();
	}
	
	private void switchPlayer(boolean toMe) {
		if(toMe) {
			if(myColor) {//black
				((RelativeLayout)findViewById(R.id.headerPLayer1)).setBackgroundResource(R.drawable.gradient_brown);
				((ImageView)findViewById(R.id.imageViewPlayer1Chrono)).setVisibility(View.INVISIBLE);
				((RelativeLayout)findViewById(R.id.headerPLayer2)).setBackgroundResource(R.drawable.gradient_green);
				((ImageView)findViewById(R.id.imageViewPlayer2Chrono)).setVisibility(View.VISIBLE);
				player1ElapsedTime = SystemClock.elapsedRealtime() - player1Chrono.getBase();
				player1Chrono.stop();
				player2Chrono.setBase(SystemClock.elapsedRealtime() - player2ElapsedTime);
				player2Chrono.start();
			} else { //white
				((RelativeLayout)findViewById(R.id.headerPLayer2)).setBackgroundResource(R.drawable.gradient_brown);
				((ImageView)findViewById(R.id.imageViewPlayer2Chrono)).setVisibility(View.INVISIBLE);
				((RelativeLayout)findViewById(R.id.headerPLayer1)).setBackgroundResource(R.drawable.gradient_green);
				((ImageView)findViewById(R.id.imageViewPlayer1Chrono)).setVisibility(View.VISIBLE);
				
				player2ElapsedTime = SystemClock.elapsedRealtime() - player2Chrono.getBase();
				player2Chrono.stop();
				player1Chrono.setBase(SystemClock.elapsedRealtime() - player1ElapsedTime);
				player1Chrono.start();
			}
			((Button)findViewById(R.id.buttonPass)).setEnabled(true);
		} else {
			if(myColor) {//black
				((RelativeLayout)findViewById(R.id.headerPLayer1)).setBackgroundResource(R.drawable.gradient_green);
				((ImageView)findViewById(R.id.imageViewPlayer1Chrono)).setVisibility(View.VISIBLE);
				((RelativeLayout)findViewById(R.id.headerPLayer2)).setBackgroundResource(R.drawable.gradient_brown);
				((ImageView)findViewById(R.id.imageViewPlayer2Chrono)).setVisibility(View.INVISIBLE);
				player2ElapsedTime = SystemClock.elapsedRealtime() - player2Chrono.getBase();
				player2Chrono.stop();
				player1Chrono.setBase(SystemClock.elapsedRealtime() - player1ElapsedTime);
				player1Chrono.start();
			} else {
				((RelativeLayout)findViewById(R.id.headerPLayer2)).setBackgroundResource(R.drawable.gradient_green);
				((ImageView)findViewById(R.id.imageViewPlayer2Chrono)).setVisibility(View.VISIBLE);
				((RelativeLayout)findViewById(R.id.headerPLayer1)).setBackgroundResource(R.drawable.gradient_brown);
				((ImageView)findViewById(R.id.imageViewPlayer1Chrono)).setVisibility(View.INVISIBLE);
				player1ElapsedTime = SystemClock.elapsedRealtime() - player1Chrono.getBase();
				player1Chrono.stop();
				player2Chrono.setBase(SystemClock.elapsedRealtime() - player2ElapsedTime);
				player2Chrono.start();
			}
			((Button)findViewById(R.id.buttonPass)).setEnabled(false);
		}
		myTurn = !myTurn; 
	}

	public void pass() {
		if(myTurn) return;
		mHandler.post(new Runnable() {
			@Override
			public void run() {
				((TextView)findViewById(R.id.whoPlays)).setText(myColor?"Black plays":"White plays");
				switchPlayer(true);
			}
		});
		passed = true;
	}
	
	private void loadStones() {
		findViewById(R.id.stone0_0).setTag("0:0");findViewById(R.id.stone0_1).setTag("0:1");findViewById(R.id.stone0_2).setTag("0:2");findViewById(R.id.stone0_3).setTag("0:3");findViewById(R.id.stone0_4).setTag("0:4");findViewById(R.id.stone0_5).setTag("0:5");findViewById(R.id.stone0_6).setTag("0:6");findViewById(R.id.stone0_7).setTag("0:7");findViewById(R.id.stone0_8).setTag("0:8");
		findViewById(R.id.stone1_0).setTag("1:0");findViewById(R.id.stone1_1).setTag("1:1");findViewById(R.id.stone1_2).setTag("1:2");findViewById(R.id.stone1_3).setTag("1:3");findViewById(R.id.stone1_4).setTag("1:4");findViewById(R.id.stone1_5).setTag("1:5");findViewById(R.id.stone1_6).setTag("1:6");findViewById(R.id.stone1_7).setTag("1:7");findViewById(R.id.stone1_8).setTag("1:8");
		findViewById(R.id.stone2_0).setTag("2:0");findViewById(R.id.stone2_1).setTag("2:1");findViewById(R.id.stone2_2).setTag("2:2");findViewById(R.id.stone2_3).setTag("2:3");findViewById(R.id.stone2_4).setTag("2:4");findViewById(R.id.stone2_5).setTag("2:5");findViewById(R.id.stone2_6).setTag("2:6");findViewById(R.id.stone2_7).setTag("2:7");findViewById(R.id.stone2_8).setTag("2:8");
		findViewById(R.id.stone3_0).setTag("3:0");findViewById(R.id.stone3_1).setTag("3:1");findViewById(R.id.stone3_2).setTag("3:2");findViewById(R.id.stone3_3).setTag("3:3");findViewById(R.id.stone3_4).setTag("3:4");findViewById(R.id.stone3_5).setTag("3:5");findViewById(R.id.stone3_6).setTag("3:6");findViewById(R.id.stone3_7).setTag("3:7");findViewById(R.id.stone3_8).setTag("3:8");
		findViewById(R.id.stone4_0).setTag("4:0");findViewById(R.id.stone4_1).setTag("4:1");findViewById(R.id.stone4_2).setTag("4:2");findViewById(R.id.stone4_3).setTag("4:3");findViewById(R.id.stone4_4).setTag("4:4");findViewById(R.id.stone4_5).setTag("4:5");findViewById(R.id.stone4_6).setTag("4:6");findViewById(R.id.stone4_7).setTag("4:7");findViewById(R.id.stone4_8).setTag("4:8");
		findViewById(R.id.stone5_0).setTag("5:0");findViewById(R.id.stone5_1).setTag("5:1");findViewById(R.id.stone5_2).setTag("5:2");findViewById(R.id.stone5_3).setTag("5:3");findViewById(R.id.stone5_4).setTag("5:4");findViewById(R.id.stone5_5).setTag("5:5");findViewById(R.id.stone5_6).setTag("5:6");findViewById(R.id.stone5_7).setTag("5:7");findViewById(R.id.stone5_8).setTag("5:8");
		findViewById(R.id.stone6_0).setTag("6:0");findViewById(R.id.stone6_1).setTag("6:1");findViewById(R.id.stone6_2).setTag("6:2");findViewById(R.id.stone6_3).setTag("6:3");findViewById(R.id.stone6_4).setTag("6:4");findViewById(R.id.stone6_5).setTag("6:5");findViewById(R.id.stone6_6).setTag("6:6");findViewById(R.id.stone6_7).setTag("6:7");findViewById(R.id.stone6_8).setTag("6:8");
		findViewById(R.id.stone7_0).setTag("7:0");findViewById(R.id.stone7_1).setTag("7:1");findViewById(R.id.stone7_2).setTag("7:2");findViewById(R.id.stone7_3).setTag("7:3");findViewById(R.id.stone7_4).setTag("7:4");findViewById(R.id.stone7_5).setTag("7:5");findViewById(R.id.stone7_6).setTag("7:6");findViewById(R.id.stone7_7).setTag("7:7");findViewById(R.id.stone7_8).setTag("7:8");
		findViewById(R.id.stone8_0).setTag("8:0");findViewById(R.id.stone8_1).setTag("8:1");findViewById(R.id.stone8_2).setTag("8:2");findViewById(R.id.stone8_3).setTag("8:3");findViewById(R.id.stone8_4).setTag("8:4");findViewById(R.id.stone8_5).setTag("8:5");findViewById(R.id.stone8_6).setTag("8:6");findViewById(R.id.stone8_7).setTag("8:7");findViewById(R.id.stone8_8).setTag("8:8");
	}
	
	private Integer[][] stones = {
			{R.id.stone0_0,R.id.stone0_1,R.id.stone0_2,R.id.stone0_3,R.id.stone0_4,R.id.stone0_5,R.id.stone0_6,R.id.stone0_7,R.id.stone0_8},
			{R.id.stone1_0,R.id.stone1_1,R.id.stone1_2,R.id.stone1_3,R.id.stone1_4,R.id.stone1_5,R.id.stone1_6,R.id.stone1_7,R.id.stone1_8},
			{R.id.stone2_0,R.id.stone2_1,R.id.stone2_2,R.id.stone2_3,R.id.stone2_4,R.id.stone2_5,R.id.stone2_6,R.id.stone2_7,R.id.stone2_8},
			{R.id.stone3_0,R.id.stone3_1,R.id.stone3_2,R.id.stone3_3,R.id.stone3_4,R.id.stone3_5,R.id.stone3_6,R.id.stone3_7,R.id.stone3_8},
			{R.id.stone4_0,R.id.stone4_1,R.id.stone4_2,R.id.stone4_3,R.id.stone4_4,R.id.stone4_5,R.id.stone4_6,R.id.stone4_7,R.id.stone4_8},
			{R.id.stone5_0,R.id.stone5_1,R.id.stone5_2,R.id.stone5_3,R.id.stone5_4,R.id.stone5_5,R.id.stone5_6,R.id.stone5_7,R.id.stone5_8},
			{R.id.stone6_0,R.id.stone6_1,R.id.stone6_2,R.id.stone6_3,R.id.stone6_4,R.id.stone6_5,R.id.stone6_6,R.id.stone6_7,R.id.stone6_8},
			{R.id.stone7_0,R.id.stone7_1,R.id.stone7_2,R.id.stone7_3,R.id.stone7_4,R.id.stone7_5,R.id.stone7_6,R.id.stone7_7,R.id.stone7_8},
			{R.id.stone8_0,R.id.stone8_1,R.id.stone8_2,R.id.stone8_3,R.id.stone8_4,R.id.stone8_5,R.id.stone8_6,R.id.stone8_7,R.id.stone8_8},
	};
	
	public void printBoard() {
		for(int i=0;i<9;i++) {
			String rr = "";
			for(int j=0;j<9;j++)
				rr += board[i][j];
			Log.i(TAG, rr);
		}
	}
	
	public void gameOver() {
		mHandler.post(new Runnable() {
			@Override
			public void run() {
				AlertDialog.Builder builder = new AlertDialog.Builder(BoardActivity.this);
				builder.setTitle("Info")
				.setMessage("Game Over! Thanks for playing.")
						.setNegativeButton("View board", new DialogInterface.OnClickListener() {
							public void onClick(DialogInterface dialog, int whichButton) {
								
							}})
						.setPositiveButton("Exit", new DialogInterface.OnClickListener() {
								public void onClick(DialogInterface dialog, int whichButton) {
									finish();
								}})
						.create()
						.show();
				((Button)findViewById(R.id.buttonPass)).setEnabled(false);
				((Button)findViewById(R.id.buttonResign)).setEnabled(false);
				((Button)findViewById(R.id.buttonUndo)).setEnabled(false);
				player1Chrono.stop();
				player2Chrono.stop();
				gameOver = true;
			}
		});
	}
	
	public void opponentResigned() {
		mHandler.post(new Runnable() {
			@Override
			public void run() {
				AlertDialog.Builder builder = new AlertDialog.Builder(BoardActivity.this);
				builder.setTitle("Info")
				.setMessage(opponent+" has resigned from the game. Thanks for playing.")
						.setNegativeButton("View board", new DialogInterface.OnClickListener() {
							public void onClick(DialogInterface dialog, int whichButton) {
							}})
						.setPositiveButton("Exit", new DialogInterface.OnClickListener() {
								public void onClick(DialogInterface dialog, int whichButton) {
									finish();
								}})
						.create()
						.show();
				((Button)findViewById(R.id.buttonPass)).setEnabled(false);
				((Button)findViewById(R.id.buttonResign)).setEnabled(false);
				((Button)findViewById(R.id.buttonUndo)).setEnabled(false);
				player1Chrono.stop();
				player2Chrono.stop();
				gameOver = true;
			}
		});
	}
	
	public void opponentIsOffline() {
		mHandler.post(new Runnable() {
			@Override
			public void run() {
				AlertDialog.Builder builder = new AlertDialog.Builder(BoardActivity.this);
				builder.setTitle("Info")
				.setMessage(opponent+" has logged out.")
						.setNegativeButton("Wait", new DialogInterface.OnClickListener() {
							public void onClick(DialogInterface dialog, int whichButton) {
							}})
						.setPositiveButton("Exit", new DialogInterface.OnClickListener() {
								public void onClick(DialogInterface dialog, int whichButton) {
									finish();
								}})
						.create()
						.show();
			}
		});
	}
	
	//check if this stone kills any other
	//check if this stone can live here
	private boolean putStone(int color, int y, int x) {
		Stone newStone = new Stone(color, x, y, y>0?board[y-1][x]:null, y<8?board[y+1][x]:null, x<8?board[y][x+1]:null, x>0?board[y][x-1]:null);
		if(y!=0 && board[y-1][x]!=null) board[y-1][x].setDown(newStone);
		if(y!=8 && board[y+1][x]!=null) board[y+1][x].setUp(newStone);
		if(x!=8 && board[y][x+1]!=null) board[y][x+1].setLeft(newStone);
		if(x!=0 && board[y][x-1]!=null) board[y][x-1].setRight(newStone);
		board[y][x] = newStone;
		Log.i(TAG,newStone.toString());
		if(!newStone.isAlive() && !(
				//check if this stone kills any other stone
				(newStone.getUp()!=null && newStone.getUp().getColor()!=newStone.getColor() && !newStone.getUp().isAlive()) ||
				(newStone.getDown()!=null && newStone.getDown().getColor()!=newStone.getColor() && !newStone.getDown().isAlive()) ||
				(newStone.getLeft()!=null && newStone.getLeft().getColor()!=newStone.getColor() && !newStone.getLeft().isAlive()) ||
				(newStone.getRight()!=null && newStone.getRight().getColor()!=newStone.getColor() && !newStone.getRight().isAlive())
				)) {
			//new stone neither lives nor kills anybody, remove it and return false
			if(y!=0) board[y-1][x].setDown(null);
			if(y!=8) board[y+1][x].setUp(null);
			if(x!=8) board[y][x+1].setLeft(null);
			if(x!=0) board[y][x-1].setRight(null);
			board[y][x] = null;
			return false;
		}
		//remove killed stones
		if(newStone.getUp()!=null && newStone.getUp().getColor()!=newStone.getColor() && !newStone.getUp().isAlive()) {
			ArrayList<Stone> deadStones =  new ArrayList<Stone>();
			deadStones = newStone.getUp().getGroup(deadStones);
			for(Stone dead: deadStones) {
				Log.i(TAG,"killed 1: "+dead.getX()+" "+dead.getY());
				removeStone(dead);
			}
		}
		if(newStone.getDown()!=null && newStone.getDown().getColor()!=newStone.getColor() && !newStone.getDown().isAlive()) {
			ArrayList<Stone> deadStones =  new ArrayList<Stone>();
			deadStones = newStone.getDown().getGroup(deadStones);
			for(Stone dead: deadStones) {
				Log.i(TAG,"killed 2: "+dead.getX()+" "+dead.getY());
				removeStone(dead);
			}
		}
		if(newStone.getRight()!=null && newStone.getRight().getColor()!=newStone.getColor() && !newStone.getRight().isAlive()) {
			ArrayList<Stone> deadStones =  new ArrayList<Stone>();
			deadStones = newStone.getRight().getGroup(deadStones);
			for(Stone dead: deadStones) {
				Log.i(TAG,"killed 3: "+dead.getX()+" "+dead.getY());
				removeStone(dead);
			}
		}
		if(newStone.getLeft()!=null && newStone.getLeft().getColor()!=newStone.getColor() && !newStone.getLeft().isAlive()) {
			ArrayList<Stone> deadStones =  new ArrayList<Stone>();
			deadStones = newStone.getLeft().getGroup(deadStones);
			for(Stone dead: deadStones) {
				Log.i(TAG,"killed 4: "+dead.getX()+" "+dead.getY());
				removeStone(dead);
			}
		}
		return true;
	}
	
	private void removeStone(final Stone s) {
		Log.i(TAG,"remove stone: "+s.getY()+" "+s.getY());
		if(s.getX()!=0 && board[s.getY()][s.getX()-1]!=null) board[s.getY()][s.getX()-1].setRight(null);
		if(s.getX()!=8 && board[s.getY()][s.getX()+1]!=null) board[s.getY()][s.getX()+1].setLeft(null);
		if(s.getY()!=0 && board[s.getY()-1][s.getX()]!=null) board[s.getY()-1][s.getX()].setDown(null);
		if(s.getY()!=8 && board[s.getY()+1][s.getX()]!=null) board[s.getY()+1][s.getX()].setUp(null);
		board[s.getY()][s.getX()] = null;
		mHandler.post(new Runnable() {
			@Override
			public void run() {
				((ImageView)findViewById(stones[s.getX()][s.getY()])).setImageResource(R.drawable.stone_empty);
			}
		});
	}	

}
