package com.firatdulger.game.go;

import com.firatdulger.xmpp.XMPPManager;

import android.app.AlertDialog;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.os.Handler;
import android.widget.ProgressBar;

public class DialogManager {
	
	private static AlertDialog pleaseWaitDialog;
	
	public static void pleaseWaitDialog(Context context) {
		AlertDialog.Builder builder = new AlertDialog.Builder(context);
		final ProgressBar wait = new ProgressBar(context);
		pleaseWaitDialog = builder.setTitle("Please wait")
									.setView(wait)
									.setNegativeButton("Cancel", new DialogInterface.OnClickListener() {
														public void onClick(DialogInterface dialog, int whichButton) {}})
									.create();
		pleaseWaitDialog.show();
	}

	public static void closePleaseWaitDialog() {
		if(pleaseWaitDialog!=null && pleaseWaitDialog.isShowing())
			pleaseWaitDialog.dismiss();
	}
	

	
	public static void gameRequestDialog(final Context context,Handler mHandler,final String opponent) {
		mHandler.post(new Runnable() {
			
			@Override
			public void run() {
				AlertDialog.Builder builder = new AlertDialog.Builder(context);
				builder.setTitle("Info")
						.setMessage(opponent+" wants to play a game with you. Do you accept?")
						.setNegativeButton("Cancel", new DialogInterface.OnClickListener() {
							public void onClick(DialogInterface dialog, int whichButton) {
					    		XMPPManager.getInstance(context).sendMessage(opponent+context.getString(R.string.jabber_id_appendix)+"@"+context.getString(R.string.xmpp_server_address), "rejected","new_game");
							}})
						.setPositiveButton("Ok", new DialogInterface.OnClickListener() {
							public void onClick(DialogInterface dialog, int whichButton) {
					    		XMPPManager.getInstance(context).sendMessage(opponent+context.getString(R.string.jabber_id_appendix)+"@"+context.getString(R.string.xmpp_server_address), "accepted","new_game");
								Intent startMatch = new Intent(context, BoardActivity.class);
								startMatch.putExtra("opponent", opponent);
								startMatch.putExtra("myColor", "black");
								context.startActivity(startMatch);
						}})
						.create()
						.show();
			}
		});
	}
	
	public static void infoDialog(final Context context,Handler mHandler,final String info) {
		mHandler.post(new Runnable() {
			@Override
			public void run() {
				AlertDialog.Builder builder = new AlertDialog.Builder(context);
				builder.setTitle("Info")
						.setMessage(info)
						.setNegativeButton("Cancel", new DialogInterface.OnClickListener() {
							public void onClick(DialogInterface dialog, int whichButton) {}})
						.create()
						.show();
			}
		});
	}

}
