package com.firatdulger.common;

public interface EventListenerImpl {
	public void onEvent(Object arg0);
}
