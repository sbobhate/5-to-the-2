package com.firatdulger.game.go;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.IntentFilter;
import android.content.SharedPreferences;
import android.content.SharedPreferences.OnSharedPreferenceChangeListener;
import android.os.Bundle;
import android.preference.Preference;
import android.preference.Preference.OnPreferenceClickListener;
import android.preference.PreferenceFragment;
import android.support.v4.content.LocalBroadcastManager;
import android.util.Log;

public class SettingsActivity extends Activity {
	private String TAG = "SettingsActivity";

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);

		// Display the fragment as the main content.
		getFragmentManager().beginTransaction()
				.replace(android.R.id.content, new SettingsFragment()).commit();
	}
	
	@Override
	protected void onResume() {
		super.onResume();
		LocalBroadcastManager.getInstance(this).registerReceiver(mBroadcastReceiver, new IntentFilter("REGISTER_REQUEST_RESULT"));
	}
	
	@Override
	protected void onPause() {
		super.onPause();
		LocalBroadcastManager.getInstance(this).unregisterReceiver(mBroadcastReceiver);
	}

	public static class SettingsFragment extends PreferenceFragment implements
			OnSharedPreferenceChangeListener {
		private String TAG = "SettingsFragment";

		@Override
		public void onCreate(Bundle savedInstanceState) {
			super.onCreate(savedInstanceState);
			addPreferencesFromResource(R.xml.preferences);

			findPreference("pref_account_prefs_create_new_account")
					.setOnPreferenceClickListener(
							new OnPreferenceClickListener() {
								@Override
								public boolean onPreferenceClick(Preference preference) {
									AlertDialog.Builder builder = new AlertDialog.Builder(getActivity());
									builder.setMessage(R.string.pref_account_prefs_create_new_account_dialog_message)
											.setTitle(R.string.pref_account_prefs_create_new_account)
											.setPositiveButton(R.string.str_ok,
													new DialogInterface.OnClickListener() {
														public void onClick(DialogInterface dialog, int id) {
															Log.i(TAG, "create new account");
															Intent createNewAccountIntent = new Intent("MESSAGING_COMMAND");
															createNewAccountIntent.putExtra("CREATE_NEW_ACCOUNT", "username_password");
															LocalBroadcastManager.getInstance(getActivity())
																.sendBroadcast(createNewAccountIntent);
														}
													})
											.setNegativeButton(
													R.string.str_cancel,
													new DialogInterface.OnClickListener() {
														public void onClick(DialogInterface dialog, int id) { }
													});
									builder.create().show();
									return false;
								}
							});

		}

		@Override
		public void onResume() {
			super.onResume();
			getPreferenceScreen().getSharedPreferences()
					.registerOnSharedPreferenceChangeListener(this);
		}

		@Override
		public void onPause() {
			super.onPause();
			getPreferenceScreen().getSharedPreferences()
					.unregisterOnSharedPreferenceChangeListener(this);
		}

		public void onSharedPreferenceChanged(SharedPreferences sharedPreferences, String key) {
			Preference connectionPref = findPreference(key);
			if (key.equals(R.string.pref_account_prefs_password)
					&& sharedPreferences.getString(key, "").length() > 0) {
				connectionPref.setSummary(R.string.secret);
			} else {
				connectionPref.setSummary(sharedPreferences.getString(key, ""));
			}
		}
	}
	
	private BroadcastReceiver mBroadcastReceiver = new BroadcastReceiver() {
		@Override
		public void onReceive(Context context, Intent intent) {

			if(intent.getStringExtra("CAPTCHA")!=null) {
				//captcha dialog
				Log.i(TAG, "capthca: "+intent.getStringExtra("CAPTCHA"));
			} else if(intent.getStringExtra("CREATE_ACCOUNT_RESULT")!=null) {
				if(intent.getStringExtra("CREATE_ACCOUNT_RESULT").equals("TRUE")) {
					//register succesfull
				} else if(intent.getStringExtra("CREATE_ACCOUNT_RESULT").equals("FALSE")) {
					//register unsuccesfull
				}
			} 
			
		}
	};

}