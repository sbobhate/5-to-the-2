package com.firatdulger.game.go;

import java.util.ArrayList;
import java.util.concurrent.Callable;

import org.jivesoftware.smack.packet.Message;

import android.app.ActionBar;
import android.app.AlertDialog;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.os.Bundle;
import android.os.Handler;
import android.support.v4.app.Fragment;
import android.support.v4.app.FragmentActivity;
import android.support.v4.app.FragmentManager;
import android.support.v4.app.FragmentPagerAdapter;
import android.support.v4.view.ViewPager;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.EditText;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.ListView;
import android.widget.RelativeLayout;
import android.widget.ScrollView;
import android.widget.TextView;

import com.firatdulger.common.EventListenerImpl;
import com.firatdulger.common.NetworkAgent;
import com.firatdulger.xmpp.AccountManager;
import com.firatdulger.xmpp.XMPPManager;


public class RoomActivity extends FragmentActivity {
	
	private static RoomActivity mRoomActivity;
	private static String TAG = "RoomActivity";
	private static String roomName = "";
	private static int roomOccupantsCount = 0;

	private static Handler mHandler;
	SectionsPagerAdapter mSectionsPagerAdapter;
	ViewPager mViewPager;

	protected static RoomActivity getInstance() {
		return mRoomActivity;
	}
	
	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_room_);
		
		mRoomActivity=this;
		
		if(getIntent()!=null)
			roomName = getIntent().getStringExtra("roomName");
		if(roomName!=null)
			setTitle(roomName);
		
		new NetworkAgent(new EventListenerImpl() {
			@Override
			public void onEvent(Object arg0) {
				String result = (String) arg0;
				if(result==null || result.equals("")) return;
				roomOccupantsCount = Integer.parseInt(result.split(";;")[1]);
			}
		}).execute(new Callable<String>() {
			@Override
			public String call() throws Exception {
				return XMPPManager.getInstance(getApplication())
						.getRoomDescription(roomName+getString(R.string.room_name_appendix));
			}
		});
		
		mHandler = new Handler();
		
		mSectionsPagerAdapter = new SectionsPagerAdapter(getSupportFragmentManager());

		mViewPager = (ViewPager) findViewById(R.id.pager);
		mViewPager.setAdapter(mSectionsPagerAdapter);
				
		final ActionBar actionBar = getActionBar();
		actionBar.setNavigationMode(ActionBar.NAVIGATION_MODE_TABS);
		
	}
	
	@Override
	public void onResume() {
		super.onResume();
		XMPPManager.getInstance(this).addMessageListener(messageListener);
		XMPPManager.getInstance(this).addPresenceListener(presenceListener);
	}
	
	@Override
	public void onStop() {
		super.onStop();
		XMPPManager.getInstance(this).removeMessageListener(messageListener);
		XMPPManager.getInstance(this).removePresenceListener(presenceListener);
	}
	
	private EventListenerImpl messageListener = new EventListenerImpl() {
		@Override
		public void onEvent(Object arg0) {
			Message message = (Message) arg0;
			String[] messageSplitted = message.getBody().split(";;");
			if(messageSplitted==null || messageSplitted.length<2) return;
			String header = messageSplitted[0];
			String from = message.getFrom().replace(getString(R.string.jabber_id_appendix), "")
											.replace(roomName, "")
											.replace(getString(R.string.room_name_appendix), "")
											.replace(getString(R.string.xmpp_muc_service_name), "")
											.replace(getString(R.string.xmpp_server_address), "")
											.replace(getString(R.string.xmpp_resource), "")
											.replace("@", "")
											.replace("/", "");
			if(header.equals("grpcht")) {
				RoomHomeFragment.getInstance().incomingGroupChatMessage(from,messageSplitted[1]);
			} else if (header.equals("new_game")) {
				String info = messageSplitted[1];
				if(info.equals("request")) {
					DialogManager.gameRequestDialog(mRoomActivity, mHandler, from);
				} /*else if (info.equals("accepted")) {
					Intent startMatch = new Intent(RoomActivity.this, BoardActivity.class);
					startMatch.putExtra("opponent", from);
					startMatch.putExtra("myColor", "white");
					startActivity(startMatch);
				} else if (info.equals("rejected")) {
					DialogManager.closePleaseWaitDialog();
					DialogManager.infoDialog(mRoomActivity, mHandler, from + " rejected your game request");
				}*/
			}
		}
	};
	
	private EventListenerImpl presenceListener = new EventListenerImpl() {
		@Override
		public void onEvent(Object arg0) {
			Log.i(TAG,"presenceListener onEvent");
			new NetworkAgent(new EventListenerImpl() {
				@Override
				public void onEvent(Object arg0) {
					PeopleFragment.getInstance().refreshList((ArrayList<String>)arg0);
				}
			}).execute(new Callable<ArrayList<String>>() {
				@Override
				public ArrayList<String> call() throws Exception {
					return XMPPManager.getInstance(RoomActivity.this)
							.getRoomOccupants(roomName+getString(R.string.room_name_appendix) ,getString(R.string.xmpp_muc_service_name));
				}
			});
		}
	};

	public class SectionsPagerAdapter extends FragmentPagerAdapter {

		public SectionsPagerAdapter(FragmentManager fm) {
			super(fm);
		}

		@Override
		public Fragment getItem(int position) {
			Fragment result = new Fragment();
			switch (position) {
			case 0:
				Fragment fragment0 = new RoomHomeFragment();
				Bundle args0 = new Bundle();
				fragment0.setArguments(args0);
				result = fragment0;
				break;
			case 1:
				Fragment fragment1 = new PeopleFragment();
				Bundle args1 = new Bundle();
				fragment1.setArguments(args1);
				result = fragment1;
				break;
			case 2:
				Fragment fragment2 = new ActiveGamesFragment();
				Bundle args2 = new Bundle();
				fragment2.setArguments(args2);
				result = fragment2;
				break;
			default:
				break;
			}
			return result;
		}

		@Override
		public int getCount() {
			return 3;
		}

		@Override
		public CharSequence getPageTitle(int position) {
			switch (position) {
			case 0:
				return RoomHomeFragment.TITLE;
			case 1:
				return PeopleFragment.TITLE;
			case 2:
				return ActiveGamesFragment.TITLE;
			}
			return null;
		}
	}
	
	public static class PeopleFragment extends Fragment {

		public static PeopleFragment mPeopleFragment;
		public static final CharSequence TITLE = "People";
		private ListView participantsList;
		private ParticipantsArrayAdapter adapter;
		
		public PeopleFragment() {
			
		}
		
		public static PeopleFragment getInstance() {
			return mPeopleFragment;
		}
		
		@Override
		public View onCreateView(LayoutInflater inflater, ViewGroup container,
				Bundle savedInstanceState) {
			
			mPeopleFragment = this;
			View rootView = inflater.inflate(
					R.layout.activity_room, container, false);
			participantsList = (ListView) rootView
					.findViewById(R.id.occupantsList);
			adapter = new ParticipantsArrayAdapter(getActivity());
			participantsList.setAdapter(adapter);
			DialogManager.pleaseWaitDialog(getActivity());
			new NetworkAgent(new EventListenerImpl() {
				@Override
				public void onEvent(Object arg0) {
					refreshList((ArrayList<String>)arg0);
					DialogManager.closePleaseWaitDialog();
				}
			}).execute(new Callable<ArrayList<String>>() {
				@Override
				public ArrayList<String> call() throws Exception {
					return XMPPManager.getInstance(getActivity()).getRoomOccupants(roomName+getString(R.string.room_name_appendix) ,getString(R.string.xmpp_muc_service_name));
				}
			});
			return rootView;
		}
		
		public void refreshList(final ArrayList<String> dataSet) {
			mHandler.post(new Runnable() {
				@Override
				public void run() {
					if(dataSet==null || dataSet.size()<1) {
						((RelativeLayout)RoomActivity.getInstance().findViewById(R.id.noOccupant)).setVisibility(View.VISIBLE);
						((ListView)RoomActivity.getInstance().findViewById(R.id.occupantsList)).setVisibility(View.INVISIBLE);
					} else {
						((RelativeLayout)RoomActivity.getInstance().findViewById(R.id.noOccupant)).setVisibility(View.INVISIBLE);
						((ListView)RoomActivity.getInstance().findViewById(R.id.occupantsList)).setVisibility(View.VISIBLE);
						adapter.setDataSet(dataSet);
						adapter.notifyDataSetChanged();
					}
				}
			});
		}
		
		private class ParticipantsArrayAdapter extends BaseAdapter {

			private Context context;
			private ArrayList<String> dataSet;
			
			public ParticipantsArrayAdapter(Context context) {
				this.context = context;
				this.dataSet = new ArrayList<String>();
			}

			@Override
			public View getView(int position, View convertView, ViewGroup parent) {
				LayoutInflater inflater = (LayoutInflater) context.getSystemService(Context.LAYOUT_INFLATER_SERVICE);
				View rowView = inflater.inflate(R.layout.layout_occupant_list_item, parent, false);
				TextView textView = (TextView) rowView.findViewById(R.id.firstLine);
				TextView textView2 = (TextView) rowView.findViewById(R.id.secondLine);
				final ImageView iconFav = (ImageView) rowView.findViewById(R.id.occupantFavIcon);
				String occupant = dataSet.get(position);
				final String user = occupant.replace(getString(R.string.jabber_id_appendix), "")
						 .replace(roomName+getString(R.string.room_name_appendix)+"@"+getString(R.string.xmpp_muc_service_name)+"/", "");
				textView.setText(user);
				iconFav.setImageResource(AccountManager.getInstance(context).isFavourite(user)?R.drawable.ic_fav_select:R.drawable.ic_fav_deselect);
				String description = XMPPManager.getInstance(context).isRoomOccupantPresent(occupant, roomName, getString(R.string.xmpp_muc_service_name))
						?"Available":"Unavailable";
				textView2.setText(description);
				rowView.setClickable(true);
				rowView.setOnClickListener(new OnClickListener() {
					@Override
					public void onClick(View v) {
						//send game request
						if(!AccountManager.getInstance(mRoomActivity).getUsername().contains(user))
							newGameDialog(user);
					}
				});
				((RelativeLayout)rowView.findViewById(R.id.occupantFav)).setOnClickListener(new OnClickListener() {
					@Override
					public void onClick(View v) {
						if(!AccountManager.getInstance(context).isFavourite(user)) {
							AccountManager.getInstance(context).addFavourite(user);
							iconFav.setImageResource(R.drawable.ic_fav_select);
						} else {
							AccountManager.getInstance(context).removeFavourite(user);
							iconFav.setImageResource(R.drawable.ic_fav_deselect);
						}
					}
				});
				return rowView;
			}

			@Override
			public int getCount() {
				return dataSet.size();
			}

			@Override
			public Object getItem(int arg0) {
				return dataSet.get(arg0);
			}

			@Override
			public long getItemId(int arg0) {
				return arg0;
			}
			
			public void setDataSet(ArrayList<String> dataSet) {
				this.dataSet = dataSet;
			}

		}
		

		
		public void newGameDialog(final String opponent) {
			
			AlertDialog.Builder builder = new AlertDialog.Builder(getActivity());
			
			builder.setTitle("Play a game")
			
				.setMessage("Send game request to "+opponent+"?")
		
			    .setNegativeButton("Cancel", new DialogInterface.OnClickListener() {
			    	public void onClick(DialogInterface dialog, int whichButton) {}})
			        
				.setPositiveButton("Ok", new DialogInterface.OnClickListener() {
				    	public void onClick(DialogInterface dialog, int whichButton) {
				    		DialogManager.pleaseWaitDialog(getActivity());
				    		XMPPManager.getInstance(getActivity()).sendMessageForResult(opponent+getString(R.string.jabber_id_appendix)+"@"+getString(R.string.xmpp_server_address), "request","new_game",30000, new EventListenerImpl() {
								@Override
								public void onEvent(Object arg0) {
									DialogManager.closePleaseWaitDialog();
									if((Boolean)arg0) {
										Intent startMatch = new Intent(getActivity(), BoardActivity.class);
										startMatch.putExtra("opponent", opponent);
										startMatch.putExtra("myColor", "white");
										startActivity(startMatch);
									} else {
										DialogManager.infoDialog(getActivity(),mHandler,opponent+" didn't accept your match request.");
									}
								}
							});
				    	}})
			    
			    .create().show();
			
		}

	}
	
	public static class RoomHomeFragment extends Fragment {

		private static RoomHomeFragment mRoomHomeFragment;
		public static final CharSequence TITLE = "Room Home";
		private TextView groupChatTextView;
		private ScrollView mScroolView;
		
		public RoomHomeFragment() {
			
		}

		public static RoomHomeFragment getInstance() {
			return mRoomHomeFragment;
		}
		
		@Override
		public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
			mRoomHomeFragment = this;
			final View rootView = inflater.inflate(R.layout.layout_room_home, container, false);
			((TextView)rootView.findViewById(R.id.roomDescription)).setText("Welcome to "+roomName);
			groupChatTextView = ((TextView)rootView.findViewById(R.id.roomChat));
			mScroolView = ((ScrollView)rootView.findViewById(R.id.scrollView1));
			((ImageButton)rootView.findViewById(R.id.roomHomeChatSendButton)).setOnClickListener(new OnClickListener() {
				@Override
				public void onClick(View v) {
					String message = ((EditText)rootView.findViewById(R.id.roomHomeChatInput)).getText().toString();
					((EditText)rootView.findViewById(R.id.roomHomeChatInput)).setText("");
					XMPPManager.getInstance(getActivity()).sendMessagetoRoom(roomName+getString(R.string.room_name_appendix)+"@"+getString(R.string.xmpp_muc_service_name), message, "grpcht");
				}
			});
			return rootView;
		}
		
		public void incomingGroupChatMessage(final String from,final String string) {
			mHandler.post(new Runnable() {
				@Override
				public void run() {
					groupChatTextView.append(from+": "+string+"\n");
					mScroolView.fullScroll(View.FOCUS_DOWN);
				}
			});
		}

	}
	
	public static class ActiveGamesFragment extends Fragment {

		public static final CharSequence TITLE = "Active Games";
		
		public ActiveGamesFragment() {
			
		}
		
		@Override
		public View onCreateView(LayoutInflater inflater, ViewGroup container,
				Bundle savedInstanceState) {
//			View rootView = inflater.inflate(
//					R.layout.layout_active_games, container, false);
//			ListView listview = (ListView) rootView
//					.findViewById(R.id.listView1);
			TextView rootView = new TextView(getActivity());
			rootView.setText("This feature will be available soon");
			return rootView;
		}

	}
	
	

}
