package com.firatdulger.xmpp;

import android.content.Context;
import android.content.SharedPreferences;
import android.content.SharedPreferences.Editor;
import android.preference.PreferenceManager;
import android.util.Log;

public class AccountManager {
	
	private String TAG = "AccountManager";

	private SharedPreferences mSharedPreferences;
	private static AccountManager mAccountManager;
	
	private AccountManager(Context context) {
		mAccountManager = this;
		mSharedPreferences = PreferenceManager.getDefaultSharedPreferences(context);
	}
	
	public static AccountManager getInstance(Context context) {
		if(mAccountManager==null)
			mAccountManager = new AccountManager(context);
		return mAccountManager;
	}

	public boolean isAccountExists() {
		return mSharedPreferences.getString("username", null)!=null
				&& mSharedPreferences.getString("password", null)!=null;
	}
	public void saveAccount(String username,String password) {
		Editor editor = mSharedPreferences.edit();
		editor.putString("username", username);
		editor.putString("password", password);
		editor.commit();
	}
	public String getUsername() {
		return mSharedPreferences.getString("username", null);
	}
	public String getNickname(String appendix) {
		return getUsername().replace(appendix,"");
	}
	public String getPassword() {
		return mSharedPreferences.getString("password", null);
	}
	public void saveJoinedRoomsList(String rooms) {
		Editor editor = mSharedPreferences.edit();
		editor.putString("joinedRooms", rooms);
		editor.commit();
	}
	public void saveFavouritesList(String rooms) {
		Editor editor = mSharedPreferences.edit();
		editor.putString("favourites", rooms);
		editor.commit();
	}
	public String[] getJoinedRoomsList() {
		String rooms = mSharedPreferences.getString("joinedRooms", "");
		if(!rooms.equals(""))
			return rooms.split(";");
		else return new String[0];
	}
	public boolean isRoomJoined(String room){
		String rooms = mSharedPreferences.getString("joinedRooms", "");
		String[] roomsSplitted = rooms.split(";");
		for(int i=0;i<roomsSplitted.length;i++)
			if(roomsSplitted[i].equals(room))
				return true;
		return false;
	}
	public void addNewRoom(String room) {
		if(isRoomJoined(room)) return;
		String rooms = mSharedPreferences.getString("joinedRooms", "");
		rooms += room + ";";
		saveJoinedRoomsList(rooms);
	}
	public void removeRoom(String room) {
		if(!isRoomJoined(room)) return;
		String rooms = mSharedPreferences.getString("joinedRooms", "");
		rooms = rooms.replace(room+";", "");
		saveJoinedRoomsList(rooms);
	}

	public boolean isFavourite(String user) {
		String rooms = mSharedPreferences.getString("favourites", "");
		String[] favouritesSplitted = rooms.split(";");
		for(int i=0;i<favouritesSplitted.length;i++)
			if(favouritesSplitted[i].equals(user))
				return true;
		return false;
	}
	public void addFavourite(String user) {
		if(isFavourite(user)) return;
		String users = mSharedPreferences.getString("favourites", "");
		users += user + ";";
		saveFavouritesList(users);
	}
	public void removeFavourite(String user) {
		if(!isFavourite(user)) return;
		String users = mSharedPreferences.getString("favourites", "");
		users = users.replace(user+";", "");
		saveFavouritesList(users);
	}

}
