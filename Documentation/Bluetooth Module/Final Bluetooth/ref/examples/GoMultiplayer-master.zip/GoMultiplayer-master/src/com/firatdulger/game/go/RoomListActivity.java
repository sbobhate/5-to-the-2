package com.firatdulger.game.go;

import java.util.Comparator;
import java.util.concurrent.Callable;

import org.jivesoftware.smack.RosterEntry;
import org.jivesoftware.smack.packet.Message;
import org.jivesoftware.smack.packet.Presence;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.pm.PackageManager.NameNotFoundException;
import android.os.Bundle;
import android.os.Handler;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.Button;
import android.widget.ListView;
import android.widget.RelativeLayout;
import android.widget.TextView;

import com.firatdulger.common.EventListenerImpl;
import com.firatdulger.common.NetworkAgent;
import com.firatdulger.xmpp.AccountManager;
import com.firatdulger.xmpp.XMPPManager;

public class RoomListActivity extends Activity {

	private String TAG = "RoomListActivity";

	private static RoomListActivity mRoomListActivity;
	private ListView roomsList;
	private RoomsArrayAdapter adapter;
	private Handler mHandler;
	
	public static RoomListActivity getInstance() {
		return mRoomListActivity;
	}

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_rooms);
		
		mRoomListActivity = this;
		
		mHandler = new Handler();
		
		checkInternetConnection();

		roomsList = (ListView) findViewById(R.id.roomsList);
		roomsList.setClickable(true);
		
		final String[] rooms = AccountManager.getInstance(this).getJoinedRoomsList();
		adapter = new RoomsArrayAdapter(this, rooms);
		roomsList.setAdapter(adapter);
		refreshList();//this shows a message if list is empty
		
		new NetworkAgent(new EventListenerImpl() {
			@Override
			public void onEvent(Object arg0) { }
		}).execute(new Callable<Void>() {
			@Override
			public Void call() throws Exception {
				for(int i=0;i<rooms.length;i++)
					XMPPManager.getInstance(RoomListActivity.this).joinRoom(
							AccountManager.getInstance(RoomListActivity.this).getUsername(), 
							AccountManager.getInstance(RoomListActivity.this).getUsername(), 
							rooms[i]+getString(R.string.room_name_appendix), getString(R.string.xmpp_muc_service_name));
				 return null;
			}
		});
		
	}
	
	@Override
	public void onResume() {
		super.onResume();
		XMPPManager.getInstance(this).addMessageListener(messageListener);
		XMPPManager.getInstance(this).addPresenceListener(presenceListener);
	}
	
	@Override
	public void onStop() {
		super.onStop();
		XMPPManager.getInstance(this).removePresenceListener(presenceListener);
		XMPPManager.getInstance(this).removeMessageListener(messageListener);
	}

	@Override
	public boolean onCreateOptionsMenu(Menu menu) {
		// Inflate the menu; this adds items to the action bar if it is present.
		getMenuInflater().inflate(R.menu.rooms, menu);
		return true;
	}

	@Override
	public boolean onOptionsItemSelected(MenuItem item) {
		switch (item.getItemId()) {
		case R.id.action_room_list:
			roomListDialog();
			return true;
		case R.id.action_about:
			aboutDialog();
			return true;
		case R.id.action_exit:
			XMPPManager.getInstance(this).disconnect();
			finish();
			return true;
		default:
			return super.onOptionsItemSelected(item);
		}
	}
	
	private EventListenerImpl presenceListener = new EventListenerImpl() {
		@Override
		public void onEvent(Object arg0) {
			refreshList();
		}
	};
	
	private EventListenerImpl messageListener = new EventListenerImpl() {
		@Override
		public void onEvent(Object arg0) {
			Message message = (Message) arg0;
			String[] messageSplitted = message.getBody().split(";;");
			if(messageSplitted==null || messageSplitted.length<2) return;
			String header = messageSplitted[0];
			String from = message.getFrom().replace(getString(R.string.jabber_id_appendix)+"@"+
													getString(R.string.xmpp_server_address)+"/"+
													getString(R.string.xmpp_resource), "");
			if (header.equals("new_game")) {
				String info = messageSplitted[1];
				if(info.equals("request")) {
					DialogManager.gameRequestDialog(mRoomListActivity, mHandler, from);
				}
			}
		}
	};

	private class RoomsArrayAdapter extends BaseAdapter {

		private Context context;
		private String[] dataSet;
		
		public RoomsArrayAdapter(Context context,String[] dataSet) {
			this.context = context;
			this.dataSet = dataSet;
		}

		@Override
		public View getView(int position, View convertView, ViewGroup parent) {
			LayoutInflater inflater = (LayoutInflater) context.getSystemService(Context.LAYOUT_INFLATER_SERVICE);
			View rowView = inflater.inflate(R.layout.layout_room_list_item, parent, false);
			TextView textView = (TextView) rowView.findViewById(R.id.firstLine);
			TextView textView2 = (TextView) rowView.findViewById(R.id.secondLine);
			final String roomName = dataSet[position];
			textView.setText(roomName.replace(getString(R.string.room_name_appendix), ""));
			int count = XMPPManager.getInstance(context).getRoomOnlineMemberCount(roomName+getString(R.string.room_name_appendix), getString(R.string.xmpp_muc_service_name));
			String description = count +" people online";
			textView.setText(roomName.replace(getString(R.string.room_name_appendix), ""));
			textView2.setText(description);
			rowView.setClickable(true);
			rowView.setOnClickListener(new OnClickListener() {
				@Override
				public void onClick(View v) {
					Intent gotoRoom = new Intent(RoomListActivity.this,RoomActivity.class);
					gotoRoom.putExtra("roomName", roomName);
					startActivity(gotoRoom);
				}
			});

			return rowView;
		}

		@Override
		public int getCount() {
			return dataSet.length;
		}

		@Override
		public Object getItem(int arg0) {
			return dataSet[arg0];
		}

		@Override
		public long getItemId(int arg0) {
			return arg0;
		}
		
		public void setDataSet(String[] dataSet) {
			this.dataSet = dataSet;
		}

	}
	
	public void refreshList() {
		final String[] dataSet = AccountManager.getInstance(this).getJoinedRoomsList();
		mHandler.post(new Runnable() {
			@Override
			public void run() {
				if(dataSet.length<1) {
					((RelativeLayout)findViewById(R.id.noRoom)).setVisibility(View.VISIBLE);
					((ListView)findViewById(R.id.roomsList)).setVisibility(View.INVISIBLE);
					((Button)findViewById(R.id.discoverRooms)).setOnClickListener(new OnClickListener() {
						@Override
						public void onClick(View v) {
							roomListDialog();
						}
					});
				} else {
					((RelativeLayout)findViewById(R.id.noRoom)).setVisibility(View.INVISIBLE);
					((ListView)findViewById(R.id.roomsList)).setVisibility(View.VISIBLE);
					adapter.setDataSet(dataSet);
					adapter.notifyDataSetChanged();
				}
			}
		});
	}
	
	//In order to sort RosterEntries first by presence and than by name
	private final Comparator<? super RosterEntry> RosterEntryComparator = new Comparator<RosterEntry>() {
		@Override
		public int compare(RosterEntry lhs, RosterEntry rhs) {
			try {
				Presence lhsPres = XMPPManager.getInstance(getBaseContext()).getConnection().getRoster().getPresence(lhs.getUser());
				Presence rhsPres = XMPPManager.getInstance(getBaseContext()).getConnection().getRoster().getPresence(rhs.getUser());
				if(Presence.Type.available.equals(lhsPres.getType()) && !Presence.Type.available.equals(rhsPres.getType())) return -1;
				if(Presence.Type.available.equals(rhsPres.getType()) && !Presence.Type.available.equals(lhsPres.getType())) return 1;
			} catch (NullPointerException nex) {
				Log.e(TAG,"RosterEntryComparator", nex);
			}
			return lhs.getUser().compareTo(rhs.getUser());
		}
	};
	
	public void roomListDialog() {

		final String[] items = getResources().getStringArray(R.array.room_names);
		boolean[] isSelectd = new boolean[items.length];
		for(int i=0;i<items.length;i++) {
			isSelectd[i] = AccountManager.getInstance(getBaseContext()).isRoomJoined(items[i]);
		}
		
		AlertDialog.Builder builder = new AlertDialog.Builder(RoomListActivity.getInstance());
		builder.setTitle("Select rooms to join")
			.setMultiChoiceItems(items, isSelectd, new DialogInterface.OnMultiChoiceClickListener() {
				@Override
				public void onClick(DialogInterface dialog, int which, boolean isChecked) {
						if(isChecked)
							AccountManager.getInstance(getBaseContext()).addNewRoom((String)items[which]);
						else
							AccountManager.getInstance(getBaseContext()).removeRoom((String)items[which]);
				}
			})
			.setPositiveButton("Ok", new DialogInterface.OnClickListener() {
			    	public void onClick(DialogInterface dialog, int whichButton) {
			    		refreshList();
			    	}})
		    .create()
		    .show();
		
	}
	
	public void aboutDialog() {
		AlertDialog.Builder builder = new AlertDialog.Builder(this);
		String versionName = "1.0";
		int versionCode = 1;
		try {
			versionName = getPackageManager()
				    .getPackageInfo(getPackageName(), 0).versionName;
			versionCode = getPackageManager()
				    .getPackageInfo(getPackageName(), 0).versionCode;
		} catch (NameNotFoundException e) {
			e.printStackTrace();
		}
		builder.setTitle("About")
			.setMessage(getString(R.string.about_message).replace("*version*","v"+versionName+"."+versionCode))
			.setPositiveButton("Close", new DialogInterface.OnClickListener() {
	    	public void onClick(DialogInterface dialog, int whichButton) {}})
		    .create().show();
	}
	
	public void infoDialog(final String info) {
		mHandler.post(new Runnable() {
			@Override
			public void run() {
				AlertDialog.Builder builder = new AlertDialog.Builder(RoomListActivity.this);
				builder.setTitle("Info")
						.setMessage(info)
						.setNegativeButton("Cancel", new DialogInterface.OnClickListener() {
							public void onClick(DialogInterface dialog, int whichButton) {}})
						.create()
						.show();
			}
		});
	}
	
	//TODO checks the connection and redirects to error page if not connected
	public void checkInternetConnection() {
		
	}
}
