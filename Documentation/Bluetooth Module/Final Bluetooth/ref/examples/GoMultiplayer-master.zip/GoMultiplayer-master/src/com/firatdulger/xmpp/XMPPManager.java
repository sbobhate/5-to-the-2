package com.firatdulger.xmpp;

import java.util.ArrayList;
import java.util.Collection;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Timer;
import java.util.TimerTask;

import org.jivesoftware.smack.Connection;
import org.jivesoftware.smack.ConnectionConfiguration;
import org.jivesoftware.smack.ConnectionListener;
import org.jivesoftware.smack.PacketListener;
import org.jivesoftware.smack.Roster;
import org.jivesoftware.smack.RosterEntry;
import org.jivesoftware.smack.SASLAuthentication;
import org.jivesoftware.smack.SmackAndroid;
import org.jivesoftware.smack.SmackConfiguration;
import org.jivesoftware.smack.XMPPConnection;
import org.jivesoftware.smack.XMPPException;
import org.jivesoftware.smack.filter.PacketFilter;
import org.jivesoftware.smack.packet.Message;
import org.jivesoftware.smack.packet.Packet;
import org.jivesoftware.smack.packet.Presence;
import org.jivesoftware.smackx.muc.DiscussionHistory;
import org.jivesoftware.smackx.muc.HostedRoom;
import org.jivesoftware.smackx.muc.MultiUserChat;

import android.content.Context;
import android.util.Log;

import com.firatdulger.common.EventListenerImpl;

public class XMPPManager {

	private static String TAG = "XMPPManager";
	private static XMPPManager mXMPPManager;
	private SmackAndroid smackAndroid;
	private Connection connection;
	
	private Context context;

	private List<EventListenerImpl> presenceListeners;
	private List<EventListenerImpl> subscriptionListeners;
	private List<EventListenerImpl> messageListeners;
	private List<EventListenerImpl> iqListeners;
	
	private Map<String,MultiUserChat> chatRooms = new HashMap<String,MultiUserChat>();
	
	public static XMPPManager getInstance(Context context) {
		if(mXMPPManager==null) mXMPPManager=new XMPPManager(context);
		return mXMPPManager;
	}
	
	private XMPPManager(Context context) {
		this.context = context;
		Connection.DEBUG_ENABLED = true;
		smackAndroid = SmackAndroid.init(context);
	}
	
	public void createNewAccount() {
		
	}
	
	public boolean connect(String server) {
		SASLAuthentication.supportSASLMechanism("PLAIN", 0);
		ConnectionConfiguration config = new ConnectionConfiguration(server, 5222);
		config.setCompressionEnabled(true);
		config.setSASLAuthenticationEnabled(true);
		config.setReconnectionAllowed(true);
	
		connection = new XMPPConnection(config);
		try {
			connection.connect();
			connection.addConnectionListener(connectionListener);
			return connection.isConnected();
		} catch (XMPPException e) {
			e.printStackTrace();
		}
		return false;
	}
	
	public void disconnect() {
		connection.disconnect();
		smackAndroid.onDestroy();
	}
	
	public boolean login(String username,String password,String resource) {
		if(!connection.isConnected()) {Log.i(TAG, "isConnected? false");return false;}
		if(!connection.isAuthenticated())
			try {
				connection.login(username, password, resource);
			} catch (XMPPException e) {
				Log.e(TAG, "XMPPException during login", e);
			}
		if(connection.isAuthenticated()) {
			initializePresenceListener();
			initializeMessageListener();
			return true;
		}
		return false;
	}
	
	public void addFriend(String name,String jabber_id) {
		Roster roster = connection.getRoster();
		try {
			roster.createEntry(jabber_id, name, null);
		} catch (XMPPException e) {
			Log.e(TAG, "Exception while adding friend", e);
		}
	}
	
	public ArrayList<RosterEntry> getRosterList(String appendix) {
		Roster roster = connection.getRoster();
		Collection<RosterEntry> entries = roster.getEntries();
		ArrayList<RosterEntry> result = new ArrayList<RosterEntry>();
		for(RosterEntry entry:entries) {
			if(entry.getUser().contains(appendix)) {
				Log.i(TAG, "getRosterList: "+entry.getName()+" "+entry.getUser()+" "+entry.getType().toString());
				result.add(entry);
			}
		}
		return result;
	}

	public void sendMessage(String user,String message,final String keyWord) {
		final Message messagePkt = new Message();
		messagePkt.setBody(keyWord+";;"+message);
		messagePkt.setTo(user);
		connection.sendPacket(messagePkt);
	}

	public void sendMessagetoRoom(String roomName,String message,final String keyWord) {
		if(!chatRooms.containsKey(roomName)) return;
		try {
			chatRooms.get(roomName).sendMessage(keyWord+";;"+message);
		} catch (XMPPException e) {
			Log.e(TAG, "Error on sending message to the room",e);
		}
	}
	public void sendMessageForResult(String user,String message,final String keyWord,long timeout,final EventListenerImpl eventListener) {

		final Timer timeout_timer = new Timer();
		final Message messagePkt = new Message();
		messagePkt.setBody(keyWord+";;"+message);
		messagePkt.setTo(user);
		connection.sendPacket(messagePkt);
		connection.addPacketListener(new PacketListener() {
			@Override
			public void processPacket(Packet arg0) {
					eventListener.onEvent(((Message)arg0).getBody().contains("accepted"));
					timeout_timer.cancel();
			        connection.removePacketListener(this);
			}
		}, new PacketFilter() {
			public boolean accept(Packet packet) {
				Log.w(TAG,"incoming: "+packet.toXML());
				if (packet!=null && packet instanceof Message && ((Message)packet).getBody().startsWith(keyWord))
					return true;
				return false;
			}
		});
		
		timeout_timer.schedule(new TimerTask() {
			@Override
			public void run() {
				eventListener.onEvent(false);
			}
		}, timeout);
		
	}
	
	public boolean isAvailable(String user) {
		Roster roster = connection.getRoster();
		return roster.getPresence(user).isAvailable();
	}

	private ConnectionListener connectionListener = new ConnectionListener() {
		
		@Override
		public void reconnectionSuccessful() {
			// TODO Auto-generated method stub
			
		}
		
		@Override
		public void reconnectionFailed(Exception arg0) {
			// TODO Auto-generated method stub
			
		}
		
		@Override
		public void reconnectingIn(int arg0) {
			// TODO Auto-generated method stub
			
		}
		
		@Override
		public void connectionClosedOnError(Exception arg0) {
			// TODO Auto-generated method stub
			
		}
		
		@Override
		public void connectionClosed() {
			// TODO Auto-generated method stub
			
		}
	};

	public Connection getConnection() {
		return connection;
	}

	public void setConnection(Connection connection) {
		this.connection = connection;
	}
	
	public void initializeMessageListener() {
		connection.addPacketListener(new PacketListener() {
			@Override
			public void processPacket(Packet arg0) {
				for(EventListenerImpl listener : messageListeners)
					listener.onEvent((Message) arg0);
			}
		}, new PacketFilter() {
			public boolean accept(Packet packet) {
				if (packet instanceof Message)
					return true;
				return false;
			}
		});
	}
	
	public void initializePresenceListener() {
		connection.addPacketListener(new PacketListener() {
			@Override
			public void processPacket(Packet arg0) {
				for(EventListenerImpl listener : presenceListeners)
					listener.onEvent((Presence) arg0);
			}
		}, new PacketFilter() {
			public boolean accept(Packet packet) {
				if (packet instanceof Presence)
					return true;
				return false;
			}
		});
	}
	
	public ArrayList<String> getChatRooms(String serviceName,String appendix) {
		ArrayList<String> chatRoomNames = new ArrayList<String>();
		Collection<HostedRoom> hostedRooms = null;
		try {
			hostedRooms = MultiUserChat.getHostedRooms(connection,serviceName);
		} catch (XMPPException e) {
			e.printStackTrace();
		}
		if(hostedRooms!=null)
			for (HostedRoom room : hostedRooms)
				if(room.getJid()!=null && room.getJid().contains(appendix))
					chatRoomNames.add(room.getJid());
		return chatRoomNames;
	}
	
	public boolean joinRoom(final String jabber_id,final String nickName, final String roomName,final String serviceName) {
		MultiUserChat muc2 = new MultiUserChat(connection, roomName+"@"+serviceName);
		DiscussionHistory history = new DiscussionHistory();
		history.setMaxStanzas(20);
		try {
			muc2.join(nickName, null, history,SmackConfiguration.getPacketReplyTimeout());
		} catch (XMPPException e) {
			e.printStackTrace();
		}
		if(!chatRooms.containsKey(roomName+"@"+serviceName))
			chatRooms.put(roomName+"@"+serviceName, muc2);
		return true;
	}

	public String getRoomDescription(String roomName) {
		if(!chatRooms.containsKey(roomName)) return "Welcome;;0";
		return chatRooms.get(roomName).getSubject()+";;"+chatRooms.get(roomName).getOccupantsCount();
	}
	
	public ArrayList<String> getRoomOccupants(final String roomName,final String serviceName) {
		if (!chatRooms.containsKey(roomName+"@"+serviceName)) return null;
		Iterator<String> a =  chatRooms.get(roomName+"@"+serviceName).getOccupants();
		ArrayList<String> r = new ArrayList<String>();
		while(a.hasNext())
			r.add(a.next());
		return r;
	}
	
	public int getRoomOnlineMemberCount(final String roomName,final String serviceName) {
		if (!chatRooms.containsKey(roomName+"@"+serviceName)) {
			return 0;
		}
		Iterator<String> a =  chatRooms.get(roomName+"@"+serviceName).getOccupants();
		int r = 0;
		while(a.hasNext() && isRoomOccupantPresent(a.next(),roomName,serviceName))
			r++;
		return r;
	}
	
	public Presence getRoomOccupantPresence(final String occupantName,final String roomName,final String serviceName) {
		if (!chatRooms.containsKey(roomName+"@"+serviceName)) return null;
		return chatRooms.get(roomName+"@"+serviceName).getOccupantPresence(occupantName);
	}
	
	public boolean isRoomOccupantPresent(final String occupantName,final String roomName,final String serviceName) {
		Presence pre =  getRoomOccupantPresence(occupantName,roomName,serviceName);
		return pre!=null && pre.isAvailable();
	}

	public void addPresenceListener(EventListenerImpl listener) {
		if(presenceListeners==null)
			presenceListeners = new ArrayList<EventListenerImpl>();
		if(!presenceListeners.contains(listener))
			presenceListeners.add(listener);
	}

	public void removePresenceListener(EventListenerImpl listener) {
		if(presenceListeners==null) return;
		if(!presenceListeners.contains(listener)) return;
		presenceListeners.remove(listener);
	}
	
	public void addSubscriptionListener(EventListenerImpl listener) {
		if(subscriptionListeners==null)
			subscriptionListeners = new ArrayList<EventListenerImpl>();
		if(!subscriptionListeners.contains(listener))
			subscriptionListeners.add(listener);
	}

	public void removeSubscriptionListener(EventListenerImpl listener) {
		if(subscriptionListeners==null) return;
		if(!subscriptionListeners.contains(listener)) return;
		subscriptionListeners.remove(listener);
	}
	
	public void addMessageListener(EventListenerImpl listener) {
		if(messageListeners==null)
			messageListeners = new ArrayList<EventListenerImpl>();
		if(!messageListeners.contains(listener))
			messageListeners.add(listener);
	}

	public void removeMessageListener(EventListenerImpl listener) {
		if(messageListeners==null) return;
		if(!messageListeners.contains(listener)) return;
		messageListeners.remove(listener);
	}
	
	public void addIqListener(EventListenerImpl listener) {
		if(iqListeners==null)
			iqListeners = new ArrayList<EventListenerImpl>();
		if(!iqListeners.contains(listener))
			iqListeners.add(listener);
	}

	public void removeIqListener(EventListenerImpl listener) {
		if(iqListeners==null) return;
		if(!iqListeners.contains(listener)) return;
		iqListeners.remove(listener);
	}
	

}
