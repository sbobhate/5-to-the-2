package com.firatdulger.game.go;

import java.util.ArrayList;

public class Stone {

	private int color;
	private int x;
	private int y;
	private Stone up;
	private Stone down;
	private Stone right;
	private Stone left;
	
	private enum Direction {
		right, left, up, down, none
	}
	
	public Stone(int color, int x, int y, Stone up, Stone down, Stone right, Stone left) {
		super();
		this.color = color;
		this.x = x;
		this.y = y;
		this.up = up;
		this.down = down;
		this.right = right;
		this.left = left;
	}
	public int getColor() {
		return color;
	}
	public void setColor(int color) {
		this.color = color;
	}
	public Stone getUp() {
		return up;
	}
	public void setUp(Stone up) {
		this.up = up;
	}
	public Stone getDown() {
		return down;
	}
	public void setDown(Stone down) {
		this.down = down;
	}
	public Stone getRight() {
		return right;
	}
	public void setRight(Stone right) {
		this.right = right;
	}
	public Stone getLeft() {
		return left;
	}
	public void setLeft(Stone left) {
		this.left = left;
	}
	public int getX() {
		return x;
	}
	public void setX(int x) {
		this.x = x;
	}
	public int getY() {
		return y;
	}
	public void setY(int y) {
		this.y = y;
	}
	
	public boolean isAlive() {
		if((y!=0 && up == null) || (y!=8 && down == null) ||
				(x!=8 && right == null) || (x!=0 && left == null))
			return true;
		ArrayList<Stone> checked = new ArrayList<Stone>();
		checked.add(this);
		return (y!=0 && up.getColor()==color && up.isAlive(checked)) ||
				(y!=8 && down.getColor()==color && down.isAlive(checked)) ||
				(x!=0 && left.getColor()==color && left.isAlive(checked)) ||
				(x!=8 && right.getColor()==color && right.isAlive(checked));
	}
	
	private boolean isAlive(Direction dir) {
		if((y!=0 && up == null) || (y!=8 && down == null) ||
				(x!=8 && right == null) || (x!=0 && left == null))
			return true;
		return (y!=0 && dir!=Direction.down && up.getColor()==color && up.isAlive(Direction.up)) ||
				(y!=8 && dir!=Direction.up && down.getColor()==color && down.isAlive(Direction.down)) ||
				(x!=0 && dir!=Direction.right && left.getColor()==color && left.isAlive(Direction.left)) ||
				(x!=8 && dir!=Direction.left && right.getColor()==color && right.isAlive(Direction.right));
	}
	
	private boolean isAlive(ArrayList<Stone> alreadyChecked) {
		alreadyChecked.add(this);
		if((y!=0 && up == null) || (y!=8 && down == null) ||
				(x!=8 && right == null) || (x!=0 && left == null))
			return true;
		return (y!=0 && !alreadyChecked.contains(up) && up.getColor()==color && up.isAlive(alreadyChecked)) ||
				(y!=8 && !alreadyChecked.contains(down) && down.getColor()==color && down.isAlive(alreadyChecked)) ||
				(x!=0 && !alreadyChecked.contains(left) && left.getColor()==color && left.isAlive(alreadyChecked)) ||
				(x!=8 && !alreadyChecked.contains(right) && right.getColor()==color && right.isAlive(alreadyChecked));
	}
	
	public boolean isAliveWithout(int x,int y) {
		if (((y!=0 && up == null) && (up.getX()!=x||up.getY()!=y)) || 
				(y!=8 && down == null && (down.getX()!=x||down.getY()!=y)) || 
				(x!=0 && left == null && (left.getX()!=x||left.getY()!=y)) || 
				(x!=8 && right == null && (right.getX()!=x||right.getY()!=y)))
			return true;
		return (this.y!=0 && up.getColor()==color && up.isAliveWithout(x,y,Direction.up)) ||
				(this.y!=8 && down.getColor()==color && down.isAliveWithout(x,y,Direction.down)) ||
				(this.x!=0 && left.getColor()==color && left.isAliveWithout(x,y,Direction.left)) ||
				(this.x!=8 && right.getColor()==color && right.isAliveWithout(x,y,Direction.right));
	}
	
	private boolean isAliveWithout(int x,int y,Direction dir) {
		if (((y!=0 && up == null) && (up.getX()!=x||up.getY()!=y)) || 
				(y!=8 && down == null && (down.getX()!=x||down.getY()!=y)) || 
				(x!=0 && left == null && (left.getX()!=x||left.getY()!=y)) || 
				(x!=8 && right == null && (right.getX()!=x||right.getY()!=y)))
			return true;
		return (dir!=Direction.down && up.getColor()==color && up.isAliveWithout(x,y)) ||
				(dir!=Direction.up && down.getColor()==color && down.isAliveWithout(x,y)) ||
				(dir!=Direction.right && left.getColor()==color && left.isAliveWithout(x,y)) ||
				(dir!=Direction.left && right.getColor()==color && right.isAliveWithout(x,y));
	}
	
	public ArrayList<Stone> getGroup(ArrayList<Stone> result) {
		if(!result.contains(this))
			result.add(this);
		if(this.getUp()!=null && this.getUp().getColor()==color && !result.contains(this.getUp()))
			this.getUp().getGroup(result);
		if(this.getDown()!=null && this.getDown().getColor()==color && !result.contains(this.getDown()))
			this.getDown().getGroup(result);
		if(this.getRight()!=null && this.getRight().getColor()==color && !result.contains(this.getRight()))
			this.getRight().getGroup(result);
		if(this.getLeft()!=null && this.getLeft().getColor()==color && !result.contains(this.getLeft()))
			this.getLeft().getGroup(result);
		return result;
	}
	
	public String toString() {
		return y+","+x+" up:"+(up!=null?up.getColor():0)+" down:"+(down!=null?down.getColor():0)+" right:"+(right!=null?right.getColor():0)+" left:"+(left!=null?left.getColor():0);
	}
	
}
