package com.firatdulger.game.go;

import java.util.Timer;
import java.util.TimerTask;

import org.jivesoftware.smack.PacketListener;
import org.jivesoftware.smack.filter.PacketFilter;
import org.jivesoftware.smack.packet.IQ;
import org.jivesoftware.smack.packet.Packet;

import android.animation.Animator;
import android.animation.AnimatorListenerAdapter;
import android.annotation.TargetApi;
import android.app.Activity;
import android.content.Intent;
import android.os.AsyncTask;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.text.TextUtils;
import android.util.Log;
import android.view.KeyEvent;
import android.view.Menu;
import android.view.View;
import android.view.inputmethod.EditorInfo;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import com.firatdulger.xmpp.AccountManager;
import com.firatdulger.xmpp.XMPPManager;

/**
 * Activity which displays a login screen to the user, offering registration as
 * well.
 */
public class RegisterActivity extends Activity {
	
	private static String TAG = RegisterActivity.class.getSimpleName();
	
	/**
	 * A dummy authentication store containing known user names and passwords.
	 * TODO: remove after connecting to a real authentication system.
	 */
	private static final String[] DUMMY_CREDENTIALS = new String[] {
			"foo@example.com:hello", "bar@example.com:world" };

	/**
	 * The default email to populate the email field with.
	 */
	public static final String EXTRA_EMAIL = "com.example.android.authenticatordemo.extra.EMAIL";
	
	private Handler mHandler;

	/**
	 * Keep track of the login task to ensure we can cancel it if requested.
	 */
	private UserLoginTask mAuthTask = null;

	// Values for email and password at the time of the login attempt.
	private String mUsername;
	private String mPassword;
	private String mPasswordCheck;

	// UI references.
	private EditText mUsernameView;
	private EditText mPasswordView;
	private EditText mPasswordCheckView;
	private View mLoginFormView;
	private View mLoginStatusView;
	private TextView mLoginStatusMessageView;

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);

		setContentView(R.layout.activity_register);
		
		mHandler = new Handler();

		// Set up the login form.
		mUsernameView = (EditText) findViewById(R.id.username);

		mPasswordView = (EditText) findViewById(R.id.password);
		
		mPasswordCheckView = (EditText) findViewById(R.id.password_check);
		mPasswordCheckView
				.setOnEditorActionListener(new TextView.OnEditorActionListener() {
					@Override
					public boolean onEditorAction(TextView textView, int id,
							KeyEvent keyEvent) {
						if (id == R.id.login || id == EditorInfo.IME_NULL) {
							mUsername = mUsernameView.getText().toString();
							mPassword = mPasswordView.getText().toString();
							attemptLogin();
							return true;
						}
						return false;
					}
				});

		mLoginFormView = findViewById(R.id.login_form);
		mLoginStatusView = findViewById(R.id.login_status);
		mLoginStatusMessageView = (TextView) findViewById(R.id.login_status_message);

		findViewById(R.id.sign_in_button).setOnClickListener(
				new View.OnClickListener() {
					@Override
					public void onClick(View view) {
						mUsername = mUsernameView.getText().toString();
						mPassword = mPasswordView.getText().toString();
						mPasswordCheck = mPasswordCheckView.getText().toString();
						attemptLogin();
					}
				});

		findViewById(R.id.already_have_account).setOnClickListener(
				new View.OnClickListener() {
					@Override
					public void onClick(View view) {
						Intent signinActivity = new Intent(RegisterActivity.this, LoginActivity.class);
						startActivity(signinActivity);
						finish();
					}
				});
		
		if(AccountManager.getInstance(this).isAccountExists()) {
			Intent signinActivity = new Intent(RegisterActivity.this, LoginActivity.class);
			startActivity(signinActivity);
			finish();
		}
		
	}

	@Override
	public boolean onCreateOptionsMenu(Menu menu) {
		super.onCreateOptionsMenu(menu);
		getMenuInflater().inflate(R.menu.login, menu);
		return true;
	}

	/**
	 * Attempts to sign in or register the account specified by the login form.
	 * If there are form errors (invalid email, missing fields, etc.), the
	 * errors are presented and no actual login attempt is made.
	 */
	public void attemptLogin() {
		if (mAuthTask != null) {
			return;
		}

		// Reset errors.
		mUsernameView.setError(null);
		mPasswordView.setError(null);

		// Store values at the time of the login attempt.
//		mUsername = mUsernameView.getText().toString();
//		mPassword = mPasswordView.getText().toString();

		boolean cancel = false;
		View focusView = null;

		// Check for a valid password.
		if (!mPassword.equals(mPasswordCheck)) {
			mPasswordCheckView.setError(getString(R.string.error_field_check_fail));
			focusView = mPasswordCheckView;
			cancel = true;
		} else if (TextUtils.isEmpty(mPassword)) {
			mPasswordView.setError(getString(R.string.error_field_required));
			focusView = mPasswordView;
			cancel = true;
		} else if (mPassword.length() < 4) {
			mPasswordView.setError(getString(R.string.error_invalid_password));
			focusView = mPasswordView;
			cancel = true;
		}

		// Check for a valid email address.
		if (TextUtils.isEmpty(mUsername)) {
			mUsernameView.setError(getString(R.string.error_field_required));
			focusView = mUsernameView;
			cancel = true;
		}

		if (cancel) {
			// There was an error; don't attempt login and focus the first
			// form field with an error.
			focusView.requestFocus();
		} else {
			// Show a progress spinner, and kick off a background task to
			// perform the user login attempt.
			mLoginStatusMessageView.setText(R.string.login_progress_signing_in);
			showProgress(true);
			mAuthTask = new UserLoginTask();
			mAuthTask.execute((Void) null);
		}
	}

	/**
	 * Shows the progress UI and hides the login form.
	 */
	@TargetApi(Build.VERSION_CODES.HONEYCOMB_MR2)
	private void showProgress(final boolean show) {
		// On Honeycomb MR2 we have the ViewPropertyAnimator APIs, which allow
		// for very easy animations. If available, use these APIs to fade-in
		// the progress spinner.
		if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.HONEYCOMB_MR2) {
			int shortAnimTime = getResources().getInteger(
					android.R.integer.config_shortAnimTime);

			mLoginStatusView.setVisibility(View.VISIBLE);
			mLoginStatusView.animate().setDuration(shortAnimTime)
					.alpha(show ? 1 : 0)
					.setListener(new AnimatorListenerAdapter() {
						@Override
						public void onAnimationEnd(Animator animation) {
							mLoginStatusView.setVisibility(show ? View.VISIBLE
									: View.GONE);
						}
					});

			mLoginFormView.setVisibility(View.VISIBLE);
			mLoginFormView.animate().setDuration(shortAnimTime)
					.alpha(show ? 0 : 1)
					.setListener(new AnimatorListenerAdapter() {
						@Override
						public void onAnimationEnd(Animator animation) {
							mLoginFormView.setVisibility(show ? View.GONE
									: View.VISIBLE);
						}
					});
		} else {
			// The ViewPropertyAnimator APIs are not available, so simply show
			// and hide the relevant UI components.
			mLoginStatusView.setVisibility(show ? View.VISIBLE : View.GONE);
			mLoginFormView.setVisibility(show ? View.GONE : View.VISIBLE);
		}
	}

	/**
	 * Represents an asynchronous login/registration task used to authenticate
	 * the user.
	 */
	public class UserLoginTask extends AsyncTask<Void, Void, Void> {
		@Override
		protected Void doInBackground(Void... params) {

			if(!XMPPManager.getInstance(getApplication()).connect(getApplication().getString(R.string.xmpp_server_address))) {
				Log.e(TAG, "Can not connect to "+getApplication().getString(R.string.xmpp_server_address));
				mHandler.post(new Runnable() {
					@Override
					public void run() {
						showProgress(false);
					}
				});
				return null;
			}
			
			//We need to register
			final String mPacketId = "reg1";
			final IQ iqPacket = new IQ() {
				@Override
				public String getChildElementXML() {
					return "<query xmlns='jabber:iq:register'/>";
				}
			};
			iqPacket.setType(IQ.Type.GET);
			iqPacket.setTo(getString(R.string.xmpp_server_address));
			iqPacket.setPacketID(mPacketId);
			XMPPManager.getInstance(getApplication()).getConnection().sendPacket(iqPacket);
			XMPPManager.getInstance(getApplication()).getConnection().addPacketListener(new PacketListener() {
				@Override
				public void processPacket(Packet response) {
					Log.i(TAG, "Register request response: "+response.toXML());
					if(response.toXML().contains("error")) {
						onLoginFailed();
						XMPPManager.getInstance(getApplication()).getConnection().removePacketListener(this);
						return;
					}
					
					/*
					 * <iq id="reg1" from="is-a-furry.org" type="result"><query xmlns="jabber:iq:register">
					 * <instructions>Choose a username and password for use with this service.</instructions>
					 * <password></password>
					 * <username></username>
					 * <x xmlns="jabber:x:data" type="form">
					 * <title>Creating a new account</title>
					 * <instructions>Choose a username and password for use with this service.</instructions>
					 * <field label="Username" var="username" type="text-single"><required/></field>
					 * <field label="Password" var="password" type="text-private"><required/></field>
					 * </x>
					 * </query>
					 * </iq>
					 */
					
					final String mPacketId = "reg2";
					final IQ iqPacket = new IQ() {
						@Override
						public String getChildElementXML() {
							return "<query xmlns='jabber:iq:register'>" +
										"<x xmlns='jabber:x:data' type='submit'>" +
											"<field type='hidden' var='FORM_TYPE'>" +
												"<value>jabber:iq:register</value>" +
											"</field>" +
											"<field type='text-single' var='username'>" +
												"<value>"+mUsername+getString(R.string.jabber_id_appendix)+"</value>" +
											"</field>" +
											"<field type='text-private' var='password'>" +
												"<value>"+mPassword+"</value>" +
											"</field>" +
										"</x>" +
									"</query>";
						}
					};
					iqPacket.setType(IQ.Type.SET);
					iqPacket.setTo(getString(R.string.xmpp_server_address));
					iqPacket.setPacketID(mPacketId);
					Log.i(TAG, iqPacket.toXML());
					XMPPManager.getInstance(getApplication()).getConnection().sendPacket(iqPacket);
					XMPPManager.getInstance(getApplication()).getConnection().addPacketListener(new PacketListener() {
						@Override
						public void processPacket(Packet response) {
							Log.i(TAG, "Register request response 2: "+response.toXML());
							if(response.toXML().contains("error")) {
								onLoginFailed();
								XMPPManager.getInstance(getApplication()).getConnection().removePacketListener(this);
								return;
							}
							
							Log.i(TAG, "Register successfull!!");
							
							XMPPManager.getInstance(getApplication()).disconnect();
							
							XMPPManager.getInstance(getApplication()).connect(getApplication().getString(R.string.xmpp_server_address));
							
							new Timer().schedule(new TimerTask() {
								@Override
								public void run() {
									if(XMPPManager.getInstance(getApplication()).login(mUsername+getString(R.string.jabber_id_appendix), mPassword,getString(R.string.xmpp_resource))) {
										onSuccessfulLogin();
									} else {
										if(XMPPManager.getInstance(getApplication()).login(mUsername+getString(R.string.jabber_id_appendix), mPassword,getString(R.string.xmpp_resource))) {
											onSuccessfulLogin();
										} else {
											if(XMPPManager.getInstance(getApplication()).login(mUsername+getString(R.string.jabber_id_appendix), mPassword,getString(R.string.xmpp_resource))) {
												onSuccessfulLogin();
											} else {
												if(XMPPManager.getInstance(getApplication()).login(mUsername+getString(R.string.jabber_id_appendix), mPassword,getString(R.string.xmpp_resource))) {
													onSuccessfulLogin();
												} else {
													onLoginFailed();
												}
											}
										}
									}
								}
							}, 3000);
							
							XMPPManager.getInstance(getApplication()).getConnection().removePacketListener(this);
							
						}
					}, new PacketFilter() {
						@Override
						public boolean accept(Packet packet) {
							return packet.getPacketID().equals(mPacketId);
						}
					});
					
					XMPPManager.getInstance(getApplication()).getConnection().removePacketListener(this);
				}
			}, new PacketFilter() {
				@Override
				public boolean accept(Packet packet) {
					return packet.getPacketID().equals(mPacketId);
				}
			});
			
			return null;
		}

		@Override
		protected void onCancelled() {
			mAuthTask = null;
			mHandler.post(new Runnable() {
				@Override
				public void run() {
					showProgress(false);
				}
			});
		}
	}

	private void onSuccessfulLogin() {
		Log.i(TAG, "Login successful!!");
		AccountManager.getInstance(getApplication()).saveAccount(mUsername, mPassword);
		Intent goToFriendList = new Intent(RegisterActivity.this, RoomListActivity.class);
		startActivity(goToFriendList);
		finish();
	}
	
	private void onLoginFailed() {
		Log.i(TAG, "Login failed!! " + mUsername + " " + mPassword);
		mHandler.post(new Runnable() {
			@Override
			public void run() {
				showProgress(false);
				Toast.makeText(RegisterActivity.this, "Can not register!", Toast.LENGTH_SHORT).show();
			}
		});
	}
	
}
