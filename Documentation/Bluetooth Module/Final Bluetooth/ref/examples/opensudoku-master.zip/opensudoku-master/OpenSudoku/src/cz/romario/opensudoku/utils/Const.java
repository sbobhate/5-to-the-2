package cz.romario.opensudoku.utils;

public class Const {
	public static final String TAG = "OpenSudoku";

	public static final String MIME_TYPE_OPENSUDOKU = "application/x-opensudoku";

}
