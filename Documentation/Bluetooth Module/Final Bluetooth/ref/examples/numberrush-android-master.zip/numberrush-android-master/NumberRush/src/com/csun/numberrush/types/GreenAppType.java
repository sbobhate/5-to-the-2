package com.csun.numberrush.types;

public interface GreenAppType {
	// empty
}
