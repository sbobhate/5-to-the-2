package com.csun.numberrush;

import android.os.AsyncTask;
import android.os.Bundle;
import android.support.v4.app.FragmentActivity;
import android.support.v4.app.FragmentManager;


public class GreenAppBaseActivity extends FragmentActivity {
	private Thread.UncaughtExceptionHandler handler;

	@Override
	protected void onCreate(Bundle savedStateInstance) {
		super.onCreate(savedStateInstance);
		setUpDisconnectedNetworkHandler();
	}

	private void setUpDisconnectedNetworkHandler() {
		handler = new Thread.UncaughtExceptionHandler() {
			public void uncaughtException(Thread thread, Throwable e) {
				showNetworkErrorDialog(e);
			}
		};
		Thread.setDefaultUncaughtExceptionHandler(handler);
	}

	public void showNetworkErrorDialog(Throwable t) {
		FragmentManager fm = getSupportFragmentManager();
		NetworkErrorDialog d = new NetworkErrorDialog();
		d.show(fm, "Disconnected");
	}

	public boolean haveTaskAvailable(AsyncTask<?, ?, ?> task) {
		return ((task == null) || (task != null && task.getStatus() == AsyncTask.Status.FINISHED));
	}

	@Override
	protected void onDestroy() {
		super.onDestroy();
	}
}