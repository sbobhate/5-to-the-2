package com.smg.supermegagame;

import android.view.View;

public interface IViewController {
	void show();
	void hide();
	View getView();
}
