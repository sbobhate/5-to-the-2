package com.smg.supermegagame.Controller;
import com.smg.supermegagame.Model.*;

public class Controller {
	Game game;
	  //  View view;

    Controller (Game g){
	   game = g;
  }
}
