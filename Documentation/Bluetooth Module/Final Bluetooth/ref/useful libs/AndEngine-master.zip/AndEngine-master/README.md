# AndEngine

## Donations
While developing AndEngine was a lot of fun, it also also consumed many(!) months of my life. It actually continues to cost me a significant amount of money to host the AndEngine forums.

If you made profit using your game and can afford to spare a fraction of it to the developer of the game engine you used, I would be very grateful! =)

### Bitcoin
The easiest way of donating is via Bitcoin to the AndEngine funds wallet address:

![Bitcoin](http://www.andengine.org/donate/bitcoin_16x16.png "Donate via Bitcoin")
Bitcoin Wallet Address: ``1run6zViD16j2rP9evpayu8FqQ6mcRDqi`` ![Bitcoin Wallet](http://www.andengine.org/donate/bitcoin_wallet.png "Bitcoin Wallet")

### Tip4Commit (Bitcoin)
Tip the author (not the project itself) of the next commit to AndEngine:

[![Bitcoin top for next commit](http://tip4commit.com/projects/192.svg)](http://tip4commit.com/projects/192)

### PayPal
Donation Email: donate@andengine.org


Thank you!

/Nicolas Gramlich
