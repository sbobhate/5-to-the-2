/** Automatically generated file. DO NOT MODIFY */
package com.sample.turnbasedtictactoe;

public final class BuildConfig {
    public final static boolean DEBUG = true;
}