package appwarp.example.multiplayerdemo;

public class Constants {

	public static String apiKey = "1adc4a4cf9563445d1326da3485f74ec7e9286542f1f3c6b36691d100fb3c592";
    public static String secretKey =  "f11b0f2a47a699c7e5c5677a4807c53dbb98a60a08ba9598b74adf64a3616557";
    
    public static final int BananaId = 1;
    public static final int GrapeId = 2;
    public static final int PinaappleId = 3;
    public static final int StrawaryId = 4;
    
    public static final int MonsterSpeed = 400;	// px per second
    
}
