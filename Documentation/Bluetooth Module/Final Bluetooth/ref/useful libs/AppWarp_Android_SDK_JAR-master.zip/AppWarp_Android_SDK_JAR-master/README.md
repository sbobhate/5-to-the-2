AppWarp Android SDK
=======================

[![OverView](http://appwarp.shephertz.com/images/appwarp_logo.png)](http://appwarp.shephertz.com)

AppWarp client SDK JAR files for Android.

[Getting Started](http://appwarp.shephertz.com/game-development-center/android-game-developers-home/)



Sample
========
The given samples shows you how to set up your eclipse project to include the AppWarp 
SDK Jar file. It illustrates very basic connection/joining rooms etc. as well as Update and Chat APIs.

Please update the call to WarpClient initialize with the Api and Secret Key pair you
received when registering.
