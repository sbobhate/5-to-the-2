package app.appwarp.multiplayer;

public class Constants {

	public static String apiKey = "7eb1bc9e55767a734744d833a3fcf7cc0608710b0d90bcf22b65984b05b3ae16";
    public static String secretKey =  "f5485d157b11c7e08281b16c2d8c95c83d94dd78db7c2eae205073d5155100ec";
    
}
